pub struct SpriteRam {
    // TODO: sections of memory?    
}

pub struct FrameBuffer {

}

pub struct Blitter {

}
